# DermaCare Landing Page — Gentle Paws

หน้า Landing Page สำหรับ DermaCare Advanced Wound & Skin Care Spray โดย Gentle Paws
เป็นไฟล์ HTML เดี่ยว (single-file) ที่รวมรูปภาพทั้งหมดไว้ในไฟล์แล้ว (base64) ไม่ต้องพึ่งไฟล์ภายนอกอื่น ยกเว้นฟอนต์จาก Google Fonts

## โครงสร้างไฟล์

```
.
├── index.html   ← หน้าเว็บทั้งหมด (HTML + CSS + JS + รูปภาพในไฟล์เดียว)
└── README.md
```

## วิธีอัปโหลดขึ้น GitHub (ครั้งแรก)

1. สร้าง repository ใหม่บน GitHub (เช่นชื่อ `dermacare-landing`) — ไม่ต้องติ๊ก "Add a README file" เพราะมีมาให้แล้ว
2. เปิด Terminal ในโฟลเดอร์นี้ แล้วรันคำสั่งทีละบรรทัด:

```bash
git init
git add .
git commit -m "Initial commit: DermaCare landing page"
git branch -M main
git remote add origin https://github.com/<ชื่อ-user-github>/<ชื่อ-repo>.git
git push -u origin main
```

> แทน `<ชื่อ-user-github>` และ `<ชื่อ-repo>` ด้วยชื่อจริงของคุณ

## วิธีเปิดเว็บให้คนอื่นดูได้ฟรีผ่าน GitHub Pages

1. ไปที่ repository บน GitHub → แท็บ **Settings**
2. เมนูซ้าย เลือก **Pages**
3. หัวข้อ **Build and deployment** → Source เลือก **Deploy from a branch**
4. Branch เลือก **main** และโฟลเดอร์เลือก **/ (root)** แล้วกด **Save**
5. รอประมาณ 1–2 นาที เว็บจะขึ้นที่ลิงก์รูปแบบ
   `https://<ชื่อ-user-github>.github.io/<ชื่อ-repo>/`

## วิธีอัปเดตไฟล์ในครั้งถัดไป

หลังแก้ไข `index.html` แล้ว รันคำสั่ง:

```bash
git add .
git commit -m "อธิบายสิ่งที่แก้ไข"
git push
```

GitHub Pages จะอัปเดตเว็บให้อัตโนมัติภายในไม่กี่นาที

## หมายเหตุ

- ไฟล์ `index.html` มีขนาดค่อนข้างใหญ่ (~10MB) เพราะฝังรูปภาพทั้งหมดไว้ในไฟล์ (base64) — ยังอยู่ในลิมิตของ GitHub (100MB ต่อไฟล์) สบายๆ
- ถ้าต้องการแก้ไขข้อความ/ลิงก์/รูปภาพ สามารถแก้ไขไฟล์ `index.html` ได้โดยตรงด้วยโปรแกรมแก้ไขข้อความทั่วไป (เช่น VS Code)
